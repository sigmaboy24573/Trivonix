import requests
import os
import time

# Color Codes
WHITE = "\033[97m"
RED = "\033[91m"
RESET = "\033[0m"

# Banner
def print_banner():
    os.system('cls' if os.name == 'nt' else 'clear')
    banner = f"""
{WHITE}   ______     _                   _        
  /_  __/____(_)   ______  ____  (_)  __
   / / / ___/ / | / / __ \/ __ \/ / |/_/
  / / / /  / /| |/ / /_/ / / / / />  <  
 /_/ /_/  /_/ |___/\____/_/ /_/_/_/|_|   
{RESET}
{WHITE}   Dev: @king0knight
   Discord: .gg/RZmJG9nXg5{RESET}
    """
    print(banner)

# Function to validate tokens by making a simple request to Discord API
def validate_tokens(tokens):
    valid_tokens = []
    print("[-] Validating tokens...")
    for token in tokens:
        headers = {"Authorization": token}
        response = requests.get("https://discord.com/api/v9/users/@me", headers=headers)
        if response.status_code == 200:
            print(f"[-] Valid I Token start {token[:10]}*******")
            valid_tokens.append(token)
        else:
            print(f"{RED}[-] Failed I Token start {token[:10]}*******{RESET}")
    return valid_tokens

# Function to join a Discord server using an invite code
def join_server(token, invite_code):
    print(f"[-] Attempting to join server with invite code {invite_code}...")
    url = f"https://discord.com/api/v9/invites/{invite_code}"
    headers = {"Authorization": token, "Content-Type": "application/json"}
    response = requests.post(url, headers=headers, json={})
    if response.status_code == 200:
        print(f"[-] Joined I Token start {token[:10]}*******")
    elif "captcha" in response.text.lower():
        print(f"{RED}[~] Captcha I Token start {token[:10]}*******{RESET}")
    else:
        print(f"{RED}[-] Failed I Token start {token[:10]}*******{RESET}")

# Function to show tokens, masking the last 8 characters
def show_tokens(tokens):
    print("[-] Tokens (last 8 characters masked):")
    for idx, token in enumerate(tokens, 1):
        masked_token = token[:-8] + "********"
        print(f"Token {idx}: {masked_token}")

# Main function that displays the menu and executes the user’s choices
def main():
    tokens = []  # Initialize empty list for tokens

    while True:
        time.sleep(2)
        print_banner()
        print("1. Input Tokens")
        print("2. Show Tokens")
        print("3. Join a Discord server")
        print("4. Exit")
        choice = input("Enter your choice: ")

        if choice == "1":
            amount = int(input("[-] How many tokens would you like to input? "))
            for i in range(amount):
                token = input(f"[-] Enter Token {i + 1}: ")
                tokens.append(token)
            print(f"[-] Added {amount} token(s).")

        elif choice == "2":
            if not tokens:
                print("[-] No tokens available.")
            else:
                show_tokens(tokens)

        elif choice == "3":
            if not tokens:
                print("[-] No tokens available.")
                time.sleep(2)
                continue
            invite_code = input("Enter server invite code (e.g., abcd1234): ")
            valid_tokens = validate_tokens(tokens)  # Validate tokens
            if valid_tokens:
                for token in valid_tokens:
                    join_server(token, invite_code)
            else:
                print("[-] No valid tokens found.")
                time.sleep(2)

        elif choice == "4":
            print("Exiting...")
            break

        else:
            print("Invalid option!")
        
        time.sleep(2)
        os.system('cls' if os.name == 'nt' else 'clear')

if __name__ == "__main__":
    main()
